.. Pytorch Wavelets documentation master file, created by
   sphinx-quickstart on Tue Dec 11 11:56:17 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Pytorch Wavelets's documentation!
============================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   dwt
   dtcwt
   scatternet
   speed
   functions


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
